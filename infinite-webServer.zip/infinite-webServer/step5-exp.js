const excp=require("express");
let app = express();
app.listen(2005);