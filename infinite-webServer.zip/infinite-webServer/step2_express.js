const express=require("express"); // return function
let app=express(); // function return obj
app.use(express.static(__dirname));  /// set current dir
//app.use(express.static(path.join(__dirname)));

let data ={
    "heros" : [
                {"FirstName" : "Bruce" , "LastName" : "wayne"},
                 {"FirstName" : "senFi" , "LastName" : "SecLas"},
                  {"FirstName" : "ThiFir" , "LastName" : "ThiLast"},
                   {"FirstName" : "FourFirs" , "LastName" : "FourLas"},
                    {"FirstName" : "FiftFir" , "LastName" : "FiftLas"}
    ]
}
app.get("/", function(req, res){
      //  res.sendFile("/index.html");   
      //  res.sendFile(__dirname+"/index.html")  ;
     //   res.sendFile("/index.html", {root : --dirname}) ;
         res.sendFile(process.cwd()+"/index.html")  ;
    });
    app.get("/batman", function(req, res){
               
     //   res.sendFile("/index.html", {root : --dirname}) ;
         res.sendFile(process.cwd()+"/batman.html")  ;
      //  res.sendFile("/batman.html");
    })
     app.get("/batman/:bat", function(req, res){
               var param= req.params.bat;     
         res.send(`Hello ${param}`)  ;      
    })

     app.get("/404/:bat/:check", (req, res) =>{
               var param1= req.params.bat; 
               var param2= req.params.check;    
         res.send(`Hello ${param1} ${param2}`)  ;      
    })
    app.get("/data", (req, res) =>  res.send(data.heros));
app.listen(3030, "localhost", function(err){
    if(err){
        console.log("err");
    }else{
        console.log("Server is running ")
    }
});