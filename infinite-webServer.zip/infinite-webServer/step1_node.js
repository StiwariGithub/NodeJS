var http= require("http");
var fs= require("fs");
//var conf= require("./config.json");
var server = http.createServer(function(req, res){
    fs.readFile("./"+req.url, function(err, data){
        if(data){
            res.writeHead(200, {"content-type":"text/html"});
            var pdata= data+ "";
            pdata=pdata.replace("{{message}}" , "Welcome back");
            res.end(pdata);
        }else{
            res.writeHead(200, {"content-type":"text/html"});
            res.end("NoData");
        }
    })   
});
server.listen(2020, "localhost", function(){
     console.log("Server is running on port 2020 :::: ");
});