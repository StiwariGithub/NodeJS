const express=require("express"); // return function
let app=express(); // function return obj
let data ={
    "heros" : [
                {"FirstName" : "Bruce" , "LastName" : "wayne"},
                 {"FirstName" : "senFi" , "LastName" : "SecLas"},
                  {"FirstName" : "ThiFir" , "LastName" : "ThiLast"},
                   {"FirstName" : "FourFirs" , "LastName" : "FourLas"},
                    {"FirstName" : "FiftFir" , "LastName" : "FiftLas"}
    ]
}
    app.get("/", (req, res)=>res.sendFile(__dirname+"app.html"));
   app.get("/data", (req, res)=>res.send(data.heros));
   
app.listen(3040, "localhost", function(err){
    if(err){
        console.log("err");
    }else{
        console.log("Server is running ")
    }
});