const express = require("express");
let app = express();

let data = {
"heroes" : [
{ "fName" : "Bruce", "lName" : "Wayne",  "city" : "Gotham",     "power" : 6},          
{ "fName" : "Tony",  "lName" : "Stark",  "city" : "New York",   "power" : 5},          
{ "fName" : "Peter", "lName" : "Parker", "city" : "New York",   "power" : 7},          
{ "fName" : "Clark", "lName" : "Kent",   "city" : "Metropolis", "power" : 8},          
{ "fName" : "Kit",   "lName" : "Walker", "city" : "Bangala",    "power" : 6}      
]
}

app.get("/", (req,res) => res.send("<h1> Hello from Infinite Bangalore</h1>") );

app.get("/about", (req,res) => res.send("<h1> Hello from About Infinite Bangalore</h1>") )
app.get("/data", (req,res) => res.send(data.heroes) );

app.get("/product/:prod", (req,res) => {
    var param = req.params.prod;
    res.send(`<h1> Hello from Infinite ${ param } Product Bangalore</h1>`);
})

app.get("/report", (req, res) => res.redirect("/") )

app.get("*", (req,res) => res.send("<h1> we are unable to process your request</h1>"))

app.listen(4040, "localhost", (error) => {
    if(error){
        console.log(error);
    }else{
        console.log("your server is now running on localhost:4040");
    }
});