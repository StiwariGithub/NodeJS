const express = require("express");
let app = express();
// app.use(express.static(__dirname+"/public"));
app.get("/", function(reqest, response){
    // response.sendFile(__dirname+"/public/index.html");
    // response.sendFile("/public/index.html", { root : __dirname });
    response.sendFile(process.cwd()+"/public/index.html");
});
app.get("/about", function(reqest, response){
    response.sendFile("/public/about.html", {root : __dirname});
});
app.get("/batman", function(reqest, response){
    response.sendFile(process.cwd()+"/public/batman.html")
});
app.get("*", function(reqest, response){
    response.send("Page requested not found")
});
app.listen(3030, "localhost", function(error){
    if(error){
        console.log(error);
    }else{
        console.log("your server is now running on localhost:3030");
    }
});