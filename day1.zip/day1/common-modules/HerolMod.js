var Hero= {
title : "Batsman spider"
};

module.exports.power= function power() {
return 10;
};
module.exports.H=Hero;