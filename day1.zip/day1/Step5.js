var EventEmitter = require("events").EventEmitter; // inside events module class EventEmitter
var ee = new EventEmitter();
ee.addListener("infinite" , function(msg){
    console.log("Event happened" + msg);
});
var si= setInterval(function(){
ee.emit("infinite" , "My info");// emit event, created 
clearInterval(si);
}, 2000)
//ee.emit("infinite");