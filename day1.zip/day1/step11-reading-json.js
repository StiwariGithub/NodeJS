var fs= require("fs");
fs.readFile("data.json" , function(err , data){
    if(err){
        console.log(err);
    }else{
        console.log(JSON.parse(data))
         console.log(JSON.parse(data).heros[0])
    }
});
var data = require("./data.json"); // one way of reading
console.log(data.heros[1]);