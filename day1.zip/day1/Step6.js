var EventEmitter = require("events").EventEmitter; // inside events module class EventEmitter
var ee = new EventEmitter();
var count=0;
var si;
process.nextTick(function(){
    setInterval(function(){
    si= ee.emit("infinite", "Some secrete");  /// here it will invoke event, nextTick will be envoked last
     count++;
     if(count==5){
    clearInterval(si);
     };
    }, 2000)
   
});

ee.addListener("infinite" , function(msg){   // here envoked event listen
    console.log("Event happened" + msg);
});
