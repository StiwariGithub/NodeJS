var fs= require("fs");
/*fs.mkdir("temp", function(){
    console.log("created");
    fs.writeFile("temp/temp.txt" , " welcome file", function(){
    fs.exists("temp/temp.txt", function(){
        console.log("file and folder found");
        fs.appendFile("temp/temp.txt" , "Check now");
        console.log("Changes");
    });
    });
});*/

fs.mkdir("temp" , function(){
    console.log("temp fol created");
     console.log("Current working dir is " , process.cwd());
     process.chdir("temp");
     console.log("Current working dir is " , process.cwd());
     process.chdir("../");
     console.log("Current working dir is " , process.cwd());
     fs.rmdir("temp" , function(){
         console.log("Finally get removed");
     });
})