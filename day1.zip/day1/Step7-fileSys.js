var fs= require("fs");
fs.mkdir("temp", function(){
    console.log("created");
});

setTimeout(function(){
    fs.rmdir("temp");
    console.log("removed");
}, 6000);