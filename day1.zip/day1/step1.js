 var heroT= require("./common-modules/HerolMod.js");
 function someFun(){
            var count=0;
            for(var i=0 ; i<10 ; i++){
                count=i;
                console.log(count);
               
            };
            console.log("value of I :: " + heroT.H.title);
        };
        someFun();
        console.log(heroT.power());