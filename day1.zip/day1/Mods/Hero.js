export class Hero{
            constructor(fn){
                this.firstname=fn;
                this._secret="My secrete";
            }
            sayName(){
                return "My name is" + this.firstname;
            }
            set secret(newsecrete){
                this._secrete=newsecrete;
            }
            get secret(){
               return this._secrete;
            }
        };