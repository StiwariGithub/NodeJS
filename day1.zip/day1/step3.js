console.log(process.argv);
var sec= process.argv[1];
console.log(sec);