var request= require("request");
var fs = require("fs");
//var req= request("http://google.com").pipe(fs.createWriteStream("sandy.html"));
var gzip=require("zlib");
var req= request("http://google.com" , function(error, response){
    console.log(error , response);
})
.pipe(gzip.createGzip()).pipe(fs.createWriteStream("webpage.html.gz"));
req.on("finish" , function(){
    console.log("File created");
})