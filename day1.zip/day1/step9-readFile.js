var fs= require("fs");
fs.mkdir("temp", function(){
    console.log("created");
    fs.writeFile("temp.txt" , " welcome file", function(){
    console.log("Finally ready to read");
    });
});
setInterval(function(){
    fs.readFile("temp.txt" , function(er , dt){
        if(er){
            console.log(er);
        }else{
            console.log(dt + "");
        };
    })
}, 2000)