
var EventEmitter = require("events").EventEmitter; // inside events module class EventEmitter
var ee = new EventEmitter();
ee.addListener("infinite" , function(){
    console.log("Event happened");
});
var si= setInterval(function(){
ee.emit("infinite");// emit event, created 
clearInterval(si);
}, 2000)
//ee.emit("infinite");