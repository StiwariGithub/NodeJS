// console.log(process.argv[1]);
// console.log(__filename);

var val = process.argv[2];
console.log(val);