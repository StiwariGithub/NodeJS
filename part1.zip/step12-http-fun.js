var http = require("http");

var port = 1234;
var host = "localhost";

var indexpage = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to Infinite</title>
   <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
</head>
<body class="container">
    <h1 class="jumbotron">Welcome to Infinte Page</h1>
    <nav class="navbar navbar-default">
        <ul class="nav navbar-nav">
            <li><a href="#">Link</a></li>
            <li><a href="#">Link</a></li>
            <li><a href="#">Link</a></li>
            <li><a href="#">Link</a></li>
            <li><a href="#">Link</a></li>
        </ul>
    </nav>
    <section>
        <article>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima commodi vitae, vel recusandae itaque consequuntur quisquam sunt dicta placeat debitis accusantium ea nesciunt voluptatem eum laudantium laborum tempora est voluptatum.
        </article>
        <article>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima commodi vitae, vel recusandae itaque consequuntur quisquam sunt dicta placeat debitis accusantium ea nesciunt voluptatem eum laudantium laborum tempora est voluptatum.
        </article>
        <article>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima commodi vitae, vel recusandae itaque consequuntur quisquam sunt dicta placeat debitis accusantium ea nesciunt voluptatem eum laudantium laborum tempora est voluptatum.
        </article>
        <article>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima commodi vitae, vel recusandae itaque consequuntur quisquam sunt dicta placeat debitis accusantium ea nesciunt voluptatem eum laudantium laborum tempora est voluptatum.
        </article>
    </section>
    <footer>Copyrights reserved by Infinite Bangalore</footer>
</body>
</html>`;



var server = http.createServer(function(req, res){
    res.writeHead(200, {
        "Content-Type":"text/html"
    });
    
    res.write(indexpage);
    res.end();
});

server.listen(port, host, function(error){
   if(error){
    console.log(error)
   }else{
    console.log("server created on localhost:1234");
   }
});

