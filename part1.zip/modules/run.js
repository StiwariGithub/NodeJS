 Hero.run = function(){
    return this.title+" is running  at a speed of "+this.walk()*5+" kmph";
};
