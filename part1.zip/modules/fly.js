Hero.fly = function(){
    return "hero is flying"
};