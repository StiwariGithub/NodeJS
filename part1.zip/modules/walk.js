Hero.walk = function(){
    return 10;
 };