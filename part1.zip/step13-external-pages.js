var http = require("http");
var fs = require("fs");
var port = 1234;
var host = "localhost";

var server = http.createServer(function(req, res){
    res.writeHead(200, {
        "Content-Type":"text/html"
    });
    console.log(req.url);
    if(req.url === "/"){
        var data = fs.readFileSync("./text.html");
        res.write(data+"")
    }else if(req.url === "/about.html"){
        var data = fs.readFileSync("./about.html");
        res.write(data+"")
    }else{
        res.write("404 : page not found");
    };

    res.end();
});

server.listen(port, host, function(error){
   if(error){
    console.log(error)
   }else{
    console.log("server created on localhost:1234");
   }
});

