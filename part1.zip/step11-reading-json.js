/*
var fs = require("fs");
fs.readFile("data.json", function(err, data){
    if(err){
        console.log(err)
    }else{
       // console.log(data.toString())
       console.log(JSON.parse(data).heroes[0])
    }
})
*/
var data = require("./data.json");
console.log(data.heroes[1]);